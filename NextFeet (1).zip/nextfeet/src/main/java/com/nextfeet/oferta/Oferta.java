package com.nextfeet.oferta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class Oferta {

    private Integer id;
    private String nombre;
    private String tipoDescuento;
    private BigDecimal valor;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private boolean activo;
    private List<Integer> zapatillaIds;
    private List<Integer> categoriaIds;
    private int totalProductos;

    public Oferta() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoDescuento() {
        return tipoDescuento;
    }

    public void setTipoDescuento(String tipoDescuento) {
        this.tipoDescuento = tipoDescuento;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public List<Integer> getZapatillaIds() {
        return zapatillaIds;
    }

    public void setZapatillaIds(List<Integer> zapatillaIds) {
        this.zapatillaIds = zapatillaIds;
    }

    public List<Integer> getCategoriaIds() {
        return categoriaIds;
    }

    public void setCategoriaIds(List<Integer> categoriaIds) {
        this.categoriaIds = categoriaIds;
    }

    public int getTotalProductos() {
        return totalProductos;
    }

    public void setTotalProductos(int totalProductos) {
        this.totalProductos = totalProductos;
    }

    public String getEstado() {
        LocalDate hoy = LocalDate.now();
        if (!activo) {
            return "INACTIVA";
        }
        if (hoy.isBefore(fechaInicio)) {
            return "PROGRAMADA";
        }
        if (hoy.isAfter(fechaFin)) {
            return "VENCIDA";
        }
        return "VIGENTE";
    }

    /** Calcula el precio con descuento (nunca menor a cero), redondeado a 2 decimales. */
    public BigDecimal aplicar(BigDecimal precioLista) {
        BigDecimal descuento = "PORCENTAJE".equals(tipoDescuento)
                ? precioLista.multiply(valor).divide(BigDecimal.valueOf(100), 2, java.math.RoundingMode.HALF_UP)
                : valor;
        BigDecimal resultado = precioLista.subtract(descuento);
        return resultado.signum() < 0 ? BigDecimal.ZERO : resultado.setScale(2, java.math.RoundingMode.HALF_UP);
    }

}
