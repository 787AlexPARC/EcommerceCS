package com.nextfeet.oferta;

import java.util.List;

public interface OfertaDAO {

    List<Oferta> listarTodas();

    Oferta buscarPorId(int id);

    int crear(Oferta oferta);

    void actualizar(Oferta oferta);

    void cambiarEstado(int id, boolean activo);

}
