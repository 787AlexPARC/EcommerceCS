package com.nextfeet.oferta;

import java.util.List;

public interface OfertaService {

    List<Oferta> listarTodas();        // F42

    Oferta obtener(int id);

    void crearYAsignar(Oferta oferta); // F43

    void modificar(Oferta oferta);     // F44

    void desactivar(int id);           // F45

}
