package com.nextfeet.oferta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nextfeet.categoria.CategoriaService;
import com.nextfeet.common.NegocioException;
import com.nextfeet.zapatilla.ZapatillaService;

/** Interfaz 36 (panel/listado), Interfaz 37 (crear/asignar), Interfaz 38 (modificar/desactivar). F42-F45. */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/admin/ofertas")
public class AdminOfertaController {

    private final OfertaService ofertaService;
    private final ZapatillaService zapatillaService;
    private final CategoriaService categoriaService;

    public AdminOfertaController(OfertaService ofertaService, ZapatillaService zapatillaService,
            CategoriaService categoriaService) {
        this.ofertaService = ofertaService;
        this.zapatillaService = zapatillaService;
        this.categoriaService = categoriaService;
    }

    // F42: listar ofertas
    @GetMapping
    public String listar(Model model) {
        model.addAttribute("ofertas", ofertaService.listarTodas());
        return "admin/ofertas/lista";
    }

    @GetMapping("/nueva")
    public String formularioCrear(Model model) {
        model.addAttribute("oferta", new Oferta());
        cargarCatalogosAuxiliares(model);
        return "admin/ofertas/crear";
    }

    // F43: crear y asignar oferta
    @PostMapping("/nueva")
    public String crear(@RequestParam("nombre") String nombre, @RequestParam("tipoDescuento") String tipoDescuento,
            @RequestParam("valor") BigDecimal valor, @RequestParam("fechaInicio") LocalDate fechaInicio,
            @RequestParam("fechaFin") LocalDate fechaFin,
            @RequestParam(value = "zapatillaIds", required = false) List<Integer> zapatillaIds,
            @RequestParam(value = "categoriaIds", required = false) List<Integer> categoriaIds, Model model) {
        try {
            Oferta o = new Oferta();
            o.setNombre(nombre);
            o.setTipoDescuento(tipoDescuento);
            o.setValor(valor);
            o.setFechaInicio(fechaInicio);
            o.setFechaFin(fechaFin);
            o.setZapatillaIds(zapatillaIds);
            o.setCategoriaIds(categoriaIds);
            ofertaService.crearYAsignar(o); // F43
            return "redirect:/admin/ofertas";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            cargarCatalogosAuxiliares(model);
            return "admin/ofertas/crear";
        }
    }

    // Interfaz 38: modificación / desactivación
    @GetMapping("/{id}/editar")
    public String formularioEditar(@PathVariable int id, Model model) {
        model.addAttribute("oferta", ofertaService.obtener(id));
        cargarCatalogosAuxiliares(model);
        return "admin/ofertas/editar";
    }

    // F44: modificar parámetros
    @PostMapping("/{id}/editar")
    public String editar(@PathVariable int id, @RequestParam("nombre") String nombre,
            @RequestParam("tipoDescuento") String tipoDescuento, @RequestParam("valor") BigDecimal valor,
            @RequestParam("fechaInicio") LocalDate fechaInicio, @RequestParam("fechaFin") LocalDate fechaFin,
            @RequestParam(value = "zapatillaIds", required = false) List<Integer> zapatillaIds,
            @RequestParam(value = "categoriaIds", required = false) List<Integer> categoriaIds, Model model) {
        try {
            Oferta o = new Oferta();
            o.setId(id);
            o.setNombre(nombre);
            o.setTipoDescuento(tipoDescuento);
            o.setValor(valor);
            o.setFechaInicio(fechaInicio);
            o.setFechaFin(fechaFin);
            o.setZapatillaIds(zapatillaIds);
            o.setCategoriaIds(categoriaIds);
            ofertaService.modificar(o); // F44
            return "redirect:/admin/ofertas";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            cargarCatalogosAuxiliares(model);
            return "admin/ofertas/editar";
        }
    }

    // F45: desactivar (zona de peligro)
    @PostMapping("/{id}/desactivar")
    public String desactivar(@PathVariable int id) {
        ofertaService.desactivar(id); // F45
        return "redirect:/admin/ofertas";
    }

    private void cargarCatalogosAuxiliares(Model model) {
        model.addAttribute("categorias", categoriaService.listarTodas());
        model.addAttribute("zapatillas", zapatillaService.listarInventario(null, 1).getContenido());
    }

}
