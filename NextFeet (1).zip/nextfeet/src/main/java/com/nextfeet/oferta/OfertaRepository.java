package com.nextfeet.oferta;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

@Repository
public class OfertaRepository implements OfertaDAO {

    private final JdbcTemplate jdbcTemplate;

    public OfertaRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Oferta> mapper = (rs, rowNum) -> {
        Oferta o = new Oferta();
        o.setId(rs.getInt("id"));
        o.setNombre(rs.getString("nombre"));
        o.setTipoDescuento(rs.getString("tipo_descuento"));
        o.setValor(rs.getBigDecimal("valor"));
        o.setFechaInicio(rs.getDate("fecha_inicio").toLocalDate());
        o.setFechaFin(rs.getDate("fecha_fin").toLocalDate());
        o.setActivo(rs.getBoolean("activo"));
        return o;
    };

    @Override
    public List<Oferta> listarTodas() {
        List<Oferta> ofertas = jdbcTemplate.query(
                "SELECT id, nombre, tipo_descuento, valor, fecha_inicio, fecha_fin, activo " +
                        "FROM oferta ORDER BY fecha_inicio DESC", mapper);
        ofertas.forEach(this::cargarAsociaciones);
        return ofertas;
    }

    @Override
    public Oferta buscarPorId(int id) {
        List<Oferta> r = jdbcTemplate.query(
                "SELECT id, nombre, tipo_descuento, valor, fecha_inicio, fecha_fin, activo " +
                        "FROM oferta WHERE id = ?", mapper, id);
        if (r.isEmpty()) {
            return null;
        }
        Oferta o = r.get(0);
        cargarAsociaciones(o);
        return o;
    }

    private void cargarAsociaciones(Oferta o) {
        o.setZapatillaIds(jdbcTemplate.queryForList(
                "SELECT id_zapatilla FROM oferta_zapatilla WHERE id_oferta = ?", Integer.class, o.getId()));
        o.setCategoriaIds(jdbcTemplate.queryForList(
                "SELECT id_categoria FROM oferta_categoria WHERE id_oferta = ?", Integer.class, o.getId()));
        Long total = jdbcTemplate.queryForObject(
                "SELECT COUNT(DISTINCT z.id) FROM zapatilla z " +
                        "LEFT JOIN oferta_zapatilla oz ON oz.id_zapatilla = z.id AND oz.id_oferta = ? " +
                        "LEFT JOIN oferta_categoria oc ON oc.id_categoria = z.id_categoria AND oc.id_oferta = ? " +
                        "WHERE oz.id_oferta IS NOT NULL OR oc.id_oferta IS NOT NULL",
                Long.class, o.getId(), o.getId());
        o.setTotalProductos(total == null ? 0 : total.intValue());
    }

    @Override
    public int crear(Oferta o) {
        SimpleJdbcInsert insert = new SimpleJdbcInsert(jdbcTemplate)
                .withTableName("oferta").usingGeneratedKeyColumns("id");
        Number key = insert.executeAndReturnKey(Map.of(
                "nombre", o.getNombre(),
                "tipo_descuento", o.getTipoDescuento(),
                "valor", o.getValor(),
                "fecha_inicio", java.sql.Date.valueOf(o.getFechaInicio()),
                "fecha_fin", java.sql.Date.valueOf(o.getFechaFin()),
                "activo", true));
        int id = key.intValue();
        guardarAsociaciones(id, o);
        return id;
    }

    @Override
    public void actualizar(Oferta o) {
        jdbcTemplate.update(
                "UPDATE oferta SET nombre = ?, tipo_descuento = ?, valor = ?, fecha_inicio = ?, fecha_fin = ? " +
                        "WHERE id = ?",
                o.getNombre(), o.getTipoDescuento(), o.getValor(), java.sql.Date.valueOf(o.getFechaInicio()),
                java.sql.Date.valueOf(o.getFechaFin()), o.getId());
        jdbcTemplate.update("DELETE FROM oferta_zapatilla WHERE id_oferta = ?", o.getId());
        jdbcTemplate.update("DELETE FROM oferta_categoria WHERE id_oferta = ?", o.getId());
        guardarAsociaciones(o.getId(), o);
    }

    private void guardarAsociaciones(int idOferta, Oferta o) {
        if (o.getZapatillaIds() != null) {
            for (Integer idZapatilla : o.getZapatillaIds()) {
                jdbcTemplate.update("INSERT INTO oferta_zapatilla (id_oferta, id_zapatilla) VALUES (?, ?)",
                        idOferta, idZapatilla);
            }
        }
        if (o.getCategoriaIds() != null) {
            for (Integer idCategoria : o.getCategoriaIds()) {
                jdbcTemplate.update("INSERT INTO oferta_categoria (id_oferta, id_categoria) VALUES (?, ?)",
                        idOferta, idCategoria);
            }
        }
    }

    @Override
    public void cambiarEstado(int id, boolean activo) {
        jdbcTemplate.update("UPDATE oferta SET activo = ? WHERE id = ?", activo, id);
    }

}
