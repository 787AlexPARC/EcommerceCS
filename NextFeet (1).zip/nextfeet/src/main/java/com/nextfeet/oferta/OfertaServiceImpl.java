package com.nextfeet.oferta;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.nextfeet.common.NegocioException;

@Service
public class OfertaServiceImpl implements OfertaService {

    private final OfertaDAO ofertaDAO;

    public OfertaServiceImpl(OfertaDAO ofertaDAO) {
        this.ofertaDAO = ofertaDAO;
    }

    // ---------------------------------------------------------------- F42
    @Override
    public List<Oferta> listarTodas() {
        return ofertaDAO.listarTodas();
    }

    @Override
    public Oferta obtener(int id) {
        Oferta o = ofertaDAO.buscarPorId(id);
        if (o == null) {
            throw new NegocioException("La oferta no existe.");
        }
        return o;
    }

    // ---------------------------------------------------------------- F43
    @Override
    public void crearYAsignar(Oferta o) {
        validar(o);
        ofertaDAO.crear(o);
    }

    // ---------------------------------------------------------------- F44
    @Override
    public void modificar(Oferta o) {
        obtener(o.getId());
        validar(o);
        ofertaDAO.actualizar(o);
    }

    // ---------------------------------------------------------------- F45
    @Override
    public void desactivar(int id) {
        obtener(id);
        ofertaDAO.cambiarEstado(id, false);
    }

    private void validar(Oferta o) {
        if (o.getNombre() == null || o.getNombre().isBlank()) {
            throw new NegocioException("El nombre de la oferta es obligatorio.");
        }
        if (o.getValor() == null || o.getValor().compareTo(BigDecimal.ZERO) <= 0) {
            throw new NegocioException("El descuento debe ser mayor a cero.");
        }
        if ("PORCENTAJE".equals(o.getTipoDescuento()) && o.getValor().compareTo(BigDecimal.valueOf(100)) > 0) {
            throw new NegocioException("El descuento porcentual no puede superar el 100%.");
        }
        if (o.getFechaInicio() == null || o.getFechaFin() == null || o.getFechaFin().isBefore(o.getFechaInicio())) {
            throw new NegocioException("El rango de fechas de la oferta no es válido.");
        }
        boolean sinProductos = (o.getZapatillaIds() == null || o.getZapatillaIds().isEmpty())
                && (o.getCategoriaIds() == null || o.getCategoriaIds().isEmpty());
        if (sinProductos) {
            throw new NegocioException("Selecciona al menos una zapatilla o categoría para la oferta.");
        }
    }

}
