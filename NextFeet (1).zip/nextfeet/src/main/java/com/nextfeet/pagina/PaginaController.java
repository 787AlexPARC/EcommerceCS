package com.nextfeet.pagina;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.nextfeet.zapatilla.ZapatillaService;

/** Interfaz 07 (Nosotros), Interfaz 08 (Contacto, estática), Interfaz 09 (Publicidad/Home, estática). */
@Controller
public class PaginaController {

    private final ZapatillaService zapatillaService;

    public PaginaController(ZapatillaService zapatillaService) {
        this.zapatillaService = zapatillaService;
    }

    // Interfaz 09: home / banner publicitario
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("destacadas", zapatillaService.verOfertas());
        return "pagina/home";
    }

    // Interfaz 07
    @GetMapping("/nosotros")
    public String nosotros() {
        return "pagina/nosotros";
    }

    // Interfaz 08 [estático]: formulario de contacto
    @GetMapping("/contacto")
    public String contacto(Model model) {
        model.addAttribute("contacto", new ContactoDTO());
        return "pagina/contacto";
    }

    @PostMapping("/contacto")
    public String enviarContacto(@ModelAttribute("contacto") ContactoDTO dto, Model model) {
        // Página estática: no se persiste, solo se confirma la recepción del mensaje.
        model.addAttribute("enviado", true);
        model.addAttribute("contacto", new ContactoDTO());
        return "pagina/contacto";
    }

}
