package com.nextfeet.config;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.nextfeet.common.NegocioException;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(NegocioException.class)
    public String negocio(NegocioException ex, Model model) {
        model.addAttribute("mensajeError", ex.getMessage());
        return "error";
    }

    @ExceptionHandler(Exception.class)
    public String general(Exception ex, Model model) {
        ex.printStackTrace();
        model.addAttribute("mensajeError", "Ocurrió un error inesperado. Inténtalo nuevamente.");
        return "error";
    }

}
