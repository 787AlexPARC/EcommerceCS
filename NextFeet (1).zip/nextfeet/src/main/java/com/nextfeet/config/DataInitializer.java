package com.nextfeet.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nextfeet.usuario.RegistroDTO;
import com.nextfeet.usuario.UsuarioDAO;
import com.nextfeet.usuario.UsuarioService;

/** Crea los usuarios de prueba (con contraseña cifrada) al iniciar la aplicación. */
@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioService usuarioService;
    private final UsuarioDAO usuarioDAO;

    public DataInitializer(UsuarioService usuarioService, UsuarioDAO usuarioDAO) {
        this.usuarioService = usuarioService;
        this.usuarioDAO = usuarioDAO;
    }

    @Override
    public void run(String... args) {
        if (usuarioDAO.buscarPorCorreo("admin@nextfeet.com") == null) {
            usuarioService.registrarAdministrador(dto("Admin", "NextFeet", "admin@nextfeet.com", "Admin123!", "900000001"));
        }
        if (usuarioDAO.buscarPorCorreo("cliente@nextfeet.com") == null) {
            usuarioService.registrarCliente(dto("Cliente", "Prueba", "cliente@nextfeet.com", "Cliente123!", "900000002"));
        }
    }

    private RegistroDTO dto(String nombres, String apellidos, String correo, String password, String telefono) {
        RegistroDTO d = new RegistroDTO();
        d.setNombres(nombres);
        d.setApellidos(apellidos);
        d.setCorreo(correo);
        d.setPassword(password);
        d.setConfirmarPassword(password);
        d.setTelefono(telefono);
        return d;
    }

}
