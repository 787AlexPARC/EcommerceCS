package com.nextfeet.zapatilla;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.nextfeet.categoria.CategoriaService;
import com.nextfeet.common.NegocioException;

/**
 * Interfaz 29 (panel/listado), Interfaz 30 (adición), Interfaz 31 (búsqueda, integrada en el listado),
 * Interfaz 32 (detalle/edición/gestión). F33-F38.
 */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/admin/zapatillas")
public class AdminZapatillaController {

    private final ZapatillaService zapatillaService;
    private final CategoriaService categoriaService;
    private final String uploadDir;

    public AdminZapatillaController(ZapatillaService zapatillaService, CategoriaService categoriaService,
            @Value("${nextfeet.upload-dir}") String uploadDir) {
        this.zapatillaService = zapatillaService;
        this.categoriaService = categoriaService;
        this.uploadDir = uploadDir;
    }

    // F33 / F34: listado e inventario con búsqueda
    @GetMapping
    public String listar(@RequestParam(value = "q", required = false) String q,
            @RequestParam(value = "pagina", defaultValue = "1") int pagina, Model model) {
        model.addAttribute("resultado", zapatillaService.listarInventario(q, pagina));
        model.addAttribute("q", q);
        return "admin/zapatillas/lista";
    }

    @GetMapping("/nueva")
    public String formularioCrear(Model model) {
        model.addAttribute("zapatilla", new Zapatilla());
        model.addAttribute("categorias", categoriaService.listarTodas());
        return "admin/zapatillas/crear";
    }

    // F35: registrar nueva zapatilla
    @PostMapping("/nueva")
    public String crear(@RequestParam("nombre") String nombre, @RequestParam("marca") String marca,
            @RequestParam("idCategoria") int idCategoria, @RequestParam("precio") BigDecimal precio,
            @RequestParam(value = "descripcion", required = false) String descripcion,
            @RequestParam(value = "materiales", required = false) String materiales,
            @RequestParam(value = "color", required = false) String color,
            @RequestParam("tallas") List<String> tallas, @RequestParam("stocks") List<Integer> stocks,
            @RequestParam(value = "imagen", required = false) MultipartFile imagen, Model model) {
        try {
            Zapatilla z = new Zapatilla();
            z.setNombre(nombre);
            z.setMarca(marca);
            z.setIdCategoria(idCategoria);
            z.setPrecio(precio);
            z.setDescripcion(descripcion);
            z.setMateriales(materiales);
            z.setColor(color);
            z.setImagenUrl(guardarImagen(imagen));
            z.setTallas(construirTallas(tallas, stocks));
            zapatillaService.registrar(z); // F35
            return "redirect:/admin/zapatillas";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("categorias", categoriaService.listarTodas());
            return "admin/zapatillas/crear";
        }
    }

    // Interfaz 32: detalle/edición/gestión
    @GetMapping("/{id}")
    public String gestionar(@PathVariable int id, Model model) {
        model.addAttribute("zapatilla", zapatillaService.verFichaTecnica(id));
        model.addAttribute("categorias", categoriaService.listarTodas());
        model.addAttribute("historial", zapatillaService.historialStock(id));
        return "admin/zapatillas/detalle";
    }

    // F36: actualizar datos y stock
    @PostMapping("/{id}/actualizar")
    public String actualizar(@PathVariable int id, @RequestParam("nombre") String nombre,
            @RequestParam("marca") String marca, @RequestParam("idCategoria") int idCategoria,
            @RequestParam("precio") BigDecimal precio,
            @RequestParam(value = "descripcion", required = false) String descripcion,
            @RequestParam(value = "materiales", required = false) String materiales,
            @RequestParam(value = "color", required = false) String color,
            @RequestParam("tallas") List<String> tallas, @RequestParam("stocks") List<Integer> stocks,
            @RequestParam(value = "imagen", required = false) MultipartFile imagen, Model model) {
        try {
            Zapatilla actual = zapatillaService.verFichaTecnica(id);
            Zapatilla z = new Zapatilla();
            z.setId(id);
            z.setNombre(nombre);
            z.setMarca(marca);
            z.setIdCategoria(idCategoria);
            z.setPrecio(precio);
            z.setDescripcion(descripcion);
            z.setMateriales(materiales);
            z.setColor(color);
            String nuevaImagen = guardarImagen(imagen);
            z.setImagenUrl(nuevaImagen != null ? nuevaImagen : actual.getImagenUrl());
            z.setTallas(construirTallas(tallas, stocks));
            zapatillaService.actualizar(z); // F36
            return "redirect:/admin/zapatillas/" + id;
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("zapatilla", zapatillaService.verFichaTecnica(id));
            model.addAttribute("categorias", categoriaService.listarTodas());
            model.addAttribute("historial", zapatillaService.historialStock(id));
            return "admin/zapatillas/detalle";
        }
    }

    // F37: activar/desactivar visibilidad
    @PostMapping("/{id}/estado")
    public String cambiarEstado(@PathVariable int id, @RequestParam("activo") boolean activo) {
        zapatillaService.cambiarVisibilidad(id, activo);
        return "redirect:/admin/zapatillas/" + id;
    }

    // F38: eliminar
    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable int id, Model model) {
        try {
            zapatillaService.eliminar(id);
            return "redirect:/admin/zapatillas";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            return "redirect:/admin/zapatillas/" + id;
        }
    }

    private List<ZapatillaTalla> construirTallas(List<String> tallas, List<Integer> stocks) {
        List<ZapatillaTalla> lista = new ArrayList<>();
        for (int i = 0; i < tallas.size(); i++) {
            if (tallas.get(i) == null || tallas.get(i).isBlank()) {
                continue;
            }
            ZapatillaTalla t = new ZapatillaTalla();
            t.setTalla(tallas.get(i).trim());
            t.setStock(i < stocks.size() && stocks.get(i) != null ? stocks.get(i) : 0);
            lista.add(t);
        }
        return lista;
    }

    private String guardarImagen(MultipartFile imagen) {
        if (imagen == null || imagen.isEmpty()) {
            return null;
        }
        try {
            Path dir = Paths.get(uploadDir);
            Files.createDirectories(dir);
            String extension = obtenerExtension(imagen.getOriginalFilename());
            String nombreArchivo = UUID.randomUUID() + extension;
            Files.copy(imagen.getInputStream(), dir.resolve(nombreArchivo));
            return "/uploads/" + nombreArchivo;
        } catch (IOException ex) {
            throw new NegocioException("No se pudo guardar la imagen del producto.");
        }
    }

    private String obtenerExtension(String nombreOriginal) {
        if (nombreOriginal == null || !nombreOriginal.contains(".")) {
            return "";
        }
        return nombreOriginal.substring(nombreOriginal.lastIndexOf('.'));
    }

}
