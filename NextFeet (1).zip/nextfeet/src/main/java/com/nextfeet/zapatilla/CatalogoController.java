package com.nextfeet.zapatilla;

import java.math.BigDecimal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.nextfeet.categoria.CategoriaService;

/** Interfaz 04 (catálogo/filtros), Interfaz 05 (ofertas), Interfaz 06 (ficha técnica). */
@Controller
public class CatalogoController {

    private final ZapatillaService zapatillaService;
    private final CategoriaService categoriaService;

    public CatalogoController(ZapatillaService zapatillaService, CategoriaService categoriaService) {
        this.zapatillaService = zapatillaService;
        this.categoriaService = categoriaService;
    }

    // F06 / F07 / F08: catálogo, búsqueda y filtros
    @GetMapping("/catalogo")
    public String catalogo(
            @RequestParam(value = "q", required = false) String q,
            @RequestParam(value = "categoria", required = false) Integer categoriaId,
            @RequestParam(value = "marca", required = false) String marca,
            @RequestParam(value = "talla", required = false) String talla,
            @RequestParam(value = "precioMin", required = false) BigDecimal precioMin,
            @RequestParam(value = "precioMax", required = false) BigDecimal precioMax,
            @RequestParam(value = "pagina", defaultValue = "1") int pagina,
            Model model) {

        FiltroCatalogo filtro = new FiltroCatalogo();
        filtro.setQ(q);
        filtro.setCategoriaId(categoriaId);
        filtro.setMarca(marca);
        filtro.setTalla(talla);
        filtro.setPrecioMin(precioMin);
        filtro.setPrecioMax(precioMax);
        filtro.setPagina(pagina);

        model.addAttribute("resultado", zapatillaService.verCatalogo(filtro));
        model.addAttribute("categorias", categoriaService.listarTodas());
        model.addAttribute("marcas", zapatillaService.listarMarcas());
        model.addAttribute("filtro", filtro);
        return "catalogo/lista";
    }

    // F09: zapatillas en oferta
    @GetMapping("/ofertas")
    public String ofertas(Model model) {
        model.addAttribute("zapatillas", zapatillaService.verOfertas());
        return "catalogo/ofertas";
    }

    // F10: ficha técnica
    @GetMapping("/zapatilla/{id}")
    public String ficha(@PathVariable int id, Model model) {
        model.addAttribute("zapatilla", zapatillaService.verFichaTecnica(id));
        return "catalogo/detalle";
    }

}
