package com.nextfeet.zapatilla;

import java.util.List;

import com.nextfeet.common.Pagina;

public interface ZapatillaDAO {

    Zapatilla buscarPorId(int id);

    Pagina<Zapatilla> buscarCatalogo(FiltroCatalogo filtro, int tamano, boolean soloActivas);

    List<Zapatilla> buscarEnOferta();

    Pagina<Zapatilla> buscarInventario(String termino, int pagina, int tamano);

    List<String> listarMarcas();

    int crear(Zapatilla zapatilla);

    void actualizar(Zapatilla zapatilla);

    void cambiarEstado(int id, boolean activo);

    void eliminar(int id);

    boolean tienePedidosAsociados(int id);

    // Tallas / stock
    List<ZapatillaTalla> listarTallas(int idZapatilla);

    ZapatillaTalla buscarTalla(int idZapatilla, String talla);

    void guardarTallas(int idZapatilla, List<ZapatillaTalla> tallas);

    void actualizarStock(int idZapatilla, String talla, int nuevoStock);

    void registrarHistorialStock(int idZapatilla, String talla, int anterior, int nuevo, String motivo);

    List<HistorialStock> listarHistorialStock(int idZapatilla);

}
