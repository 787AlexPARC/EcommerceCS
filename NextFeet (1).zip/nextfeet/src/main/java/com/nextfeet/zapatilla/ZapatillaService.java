package com.nextfeet.zapatilla;

import java.util.List;

import com.nextfeet.common.Pagina;

public interface ZapatillaService {

    // Cliente
    Pagina<Zapatilla> verCatalogo(FiltroCatalogo filtro);          // F06 / F07 / F08

    List<Zapatilla> verOfertas();                                  // F09

    Zapatilla verFichaTecnica(int id);                              // F10

    List<String> listarMarcas();

    // Administrador
    Pagina<Zapatilla> listarInventario(String termino, int pagina); // F33 / F34

    void registrar(Zapatilla zapatilla);                            // F35

    void actualizar(Zapatilla zapatilla);                           // F36

    void actualizarStock(int idZapatilla, String talla, int nuevoStock, String motivo); // F36

    void cambiarVisibilidad(int id, boolean activo);                // F37

    void eliminar(int id);                                          // F38

    List<HistorialStock> historialStock(int id);

    // Uso interno (carrito / checkout)
    ZapatillaTalla verificarDisponibilidad(int idZapatilla, String talla, int cantidadSolicitada);

    /** Igual que buscar la talla, pero sin lanzar excepción si no hay stock (uso en reversión de inventario). */
    ZapatillaTalla verificarDisponibilidadSinLanzar(int idZapatilla, String talla);

}
