package com.nextfeet.zapatilla;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class Zapatilla {

    private Integer id;
    private String sku;
    private String nombre;
    private String marca;
    private String descripcion;
    private String materiales;
    private String color;
    private BigDecimal precio;
    private String imagenUrl;
    private Integer idCategoria;
    private String nombreCategoria;
    private boolean activo;
    private LocalDate fechaCreacion;
    private List<ZapatillaTalla> tallas;
    private int stockTotal;
    private BigDecimal precioOferta;
    private String ofertaNombre;

    public Zapatilla() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getMateriales() {
        return materiales;
    }

    public void setMateriales(String materiales) {
        this.materiales = materiales;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }

    public void setImagenUrl(String imagenUrl) {
        this.imagenUrl = imagenUrl;
    }

    public Integer getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public LocalDate getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDate fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public List<ZapatillaTalla> getTallas() {
        return tallas;
    }

    public void setTallas(List<ZapatillaTalla> tallas) {
        this.tallas = tallas;
    }

    public int getStockTotal() {
        return stockTotal;
    }

    public void setStockTotal(int stockTotal) {
        this.stockTotal = stockTotal;
    }

    public BigDecimal getPrecioOferta() {
        return precioOferta;
    }

    public void setPrecioOferta(BigDecimal precioOferta) {
        this.precioOferta = precioOferta;
    }

    public String getOfertaNombre() {
        return ofertaNombre;
    }

    public void setOfertaNombre(String ofertaNombre) {
        this.ofertaNombre = ofertaNombre;
    }

    /** Precio que paga el cliente: precio de oferta si existe, de lo contrario precio de lista. */
    public BigDecimal getPrecioFinal() {
        return precioOferta != null ? precioOferta : precio;
    }

    public boolean isEnOferta() {
        return precioOferta != null;
    }

    public int getPorcentajeDescuento() {
        if (precioOferta == null || precio == null || precio.signum() == 0) {
            return 0;
        }
        return precio.subtract(precioOferta).multiply(BigDecimal.valueOf(100))
                .divide(precio, 0, java.math.RoundingMode.HALF_UP).intValue();
    }

}
