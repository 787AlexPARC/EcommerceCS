package com.nextfeet.pedido;

public interface DireccionDAO {

    int crear(Direccion direccion);

    Direccion buscarPorId(int id);

}
