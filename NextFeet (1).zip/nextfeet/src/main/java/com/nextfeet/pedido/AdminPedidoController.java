package com.nextfeet.pedido;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nextfeet.common.NegocioException;

/** Interfaz 33 (panel/listado), Interfaz 34 (detalle/estado), Interfaz 35 (anulación). F39-F41. */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/admin/pedidos")
public class AdminPedidoController {

    private final PedidoService pedidoService;

    public AdminPedidoController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    // F39: listar pedidos globales
    @GetMapping
    public String listar(@RequestParam(value = "estado", required = false) String estado,
            @RequestParam(value = "q", required = false) String q,
            @RequestParam(value = "pagina", defaultValue = "1") int pagina, Model model) {
        model.addAttribute("resultado", pedidoService.listarGlobal(estado, q, pagina));
        model.addAttribute("estado", estado);
        model.addAttribute("q", q);
        return "admin/pedidos/lista";
    }

    // F40: detalle y cambio de estado
    @GetMapping("/{id}")
    public String detalle(@PathVariable int id, Model model) {
        model.addAttribute("pedido", pedidoService.detalleAdmin(id));
        return "admin/pedidos/detalle";
    }

    @PostMapping("/{id}/estado")
    public String actualizarEstado(@PathVariable int id, @RequestParam("estado") String estado, Model model) {
        try {
            pedidoService.actualizarEstado(id, estado); // F40
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
        }
        return "redirect:/admin/pedidos/" + id;
    }

    // F41: anular pedido
    @PostMapping("/{id}/anular")
    public String anular(@PathVariable int id, @RequestParam("motivo") String motivo, Model model) {
        try {
            pedidoService.anular(id, motivo); // F41
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
        }
        return "redirect:/admin/pedidos/" + id;
    }

}
