package com.nextfeet.pedido;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nextfeet.carrito.CarritoService;
import com.nextfeet.common.NegocioException;
import com.nextfeet.common.Sesion;

import jakarta.servlet.http.HttpSession;

/** Interfaz 11 (dirección), Interfaz 12 (pago simulado), Interfaz 13 (comprobante). */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/checkout")
public class CheckoutController {

    private final PedidoService pedidoService;
    private final CarritoService carritoService;

    public CheckoutController(PedidoService pedidoService, CarritoService carritoService) {
        this.pedidoService = pedidoService;
        this.carritoService = carritoService;
    }

    @GetMapping("/direccion")
    public String formularioDireccion(HttpSession session, Model model) {
        if (carritoService.verCarrito(Sesion.idUsuario(session)).isVacio()) {
            return "redirect:/carrito";
        }
        model.addAttribute("direccion", new Direccion());
        return "checkout/direccion";
    }

    @PostMapping("/direccion")
    public String guardarDireccion(HttpSession session, @ModelAttribute("direccion") Direccion direccion,
            Model model) {
        try {
            int idDireccion = pedidoService.registrarDireccion(Sesion.idUsuario(session), direccion); // Interfaz 11
            return "redirect:/checkout/pago?idDireccion=" + idDireccion;
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("direccion", direccion);
            return "checkout/direccion";
        }
    }

    @GetMapping("/pago")
    public String formularioPago(@org.springframework.web.bind.annotation.RequestParam("idDireccion") int idDireccion,
            Model model) {
        model.addAttribute("idDireccion", idDireccion);
        model.addAttribute("pago", new PagoDTO());
        return "checkout/pago";
    }

    // F16 / F17: procesar compra y generar comprobante
    @PostMapping("/pago")
    public String procesarPago(HttpSession session,
            @org.springframework.web.bind.annotation.RequestParam("idDireccion") int idDireccion,
            @ModelAttribute("pago") PagoDTO pago, Model model) {
        try {
            Pedido pedido = pedidoService.confirmarCompra(Sesion.idUsuario(session), idDireccion, pago);
            return "redirect:/checkout/comprobante/" + pedido.getId();
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("idDireccion", idDireccion);
            model.addAttribute("pago", pago);
            return "checkout/pago";
        }
    }

    @GetMapping("/comprobante/{idPedido}")
    public String comprobante(HttpSession session, @PathVariable int idPedido, Model model) {
        model.addAttribute("pedido", pedidoService.detalleCliente(Sesion.idUsuario(session), idPedido));
        return "checkout/comprobante";
    }

}
