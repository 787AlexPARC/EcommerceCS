package com.nextfeet.pedido;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nextfeet.common.Sesion;

import jakarta.servlet.http.HttpSession;

/** Interfaz 14 (detalle), Interfaz 15 (seguimiento), Interfaz 16 (historial). */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/mis-pedidos")
public class PedidoClienteController {

    private final PedidoService pedidoService;

    public PedidoClienteController(PedidoService pedidoService) {
        this.pedidoService = pedidoService;
    }

    // F18: historial de compras
    @GetMapping
    public String historial(HttpSession session, Model model) {
        model.addAttribute("pedidos", pedidoService.historialCliente(Sesion.idUsuario(session)));
        return "pedido/historial";
    }

    // F19: detalle de pedido
    @GetMapping("/{id}")
    public String detalle(HttpSession session, @PathVariable int id, Model model) {
        model.addAttribute("pedido", pedidoService.detalleCliente(Sesion.idUsuario(session), id));
        return "pedido/detalle";
    }

    // F20: seguimiento de envío
    @GetMapping("/{id}/seguimiento")
    public String seguimiento(HttpSession session, @PathVariable int id, Model model) {
        model.addAttribute("pedido", pedidoService.seguimiento(Sesion.idUsuario(session), id));
        return "pedido/seguimiento";
    }

}
