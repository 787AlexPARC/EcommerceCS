package com.nextfeet.pedido;

import java.util.List;

import com.nextfeet.common.Pagina;

public interface PedidoDAO {

    int crear(Pedido pedido);

    void crearDetalle(int idPedido, DetallePedido detalle);

    void registrarHistorial(int idPedido, String estado);

    Pedido buscarPorId(int id);

    List<Pedido> listarPorCliente(int idUsuario);                               // F18

    Pagina<Pedido> listarGlobal(String estado, String busqueda, int pagina, int tamano); // F39

    void actualizarEstado(int id, String nuevoEstado);                          // F40

    void anular(int id, String motivo);                                        // F41

    boolean existeCodigo(String codigo);

}
