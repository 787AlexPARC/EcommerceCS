package com.nextfeet.pedido;

import java.util.List;

import com.nextfeet.common.Pagina;

public interface PedidoService {

    int registrarDireccion(int idUsuario, Direccion direccion);                 // F (interfaz 11)

    Pedido confirmarCompra(int idUsuario, int idDireccion, PagoDTO pago);        // F16 / F17

    List<Pedido> historialCliente(int idUsuario);                               // F18

    Pedido detalleCliente(int idUsuario, int idPedido);                         // F19

    Pedido seguimiento(int idUsuario, int idPedido);                            // F20

    Pagina<Pedido> listarGlobal(String estado, String busqueda, int pagina);    // F39

    Pedido detalleAdmin(int idPedido);

    void actualizarEstado(int idPedido, String nuevoEstado);                    // F40

    void anular(int idPedido, String motivo);                                   // F41

}
