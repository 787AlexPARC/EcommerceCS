package com.nextfeet.pedido;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nextfeet.carrito.Carrito;
import com.nextfeet.carrito.CarritoDAO;
import com.nextfeet.carrito.CarritoItem;
import com.nextfeet.common.NegocioException;
import com.nextfeet.common.Pagina;
import com.nextfeet.zapatilla.ZapatillaService;
import com.nextfeet.zapatilla.ZapatillaTalla;

@Service
public class PedidoServiceImpl implements PedidoService {

    private static final List<String> FLUJO_ESTADOS =
            List.of("PENDIENTE", "EN_PREPARACION", "EN_CAMINO", "ENTREGADO");
    private static final int TAMANO_PAGINA = 10;

    private final PedidoDAO pedidoDAO;
    private final DireccionDAO direccionDAO;
    private final CarritoDAO carritoDAO;
    private final ZapatillaService zapatillaService;
    private final BigDecimal costoEnvio;

    public PedidoServiceImpl(PedidoDAO pedidoDAO, DireccionDAO direccionDAO, CarritoDAO carritoDAO,
            ZapatillaService zapatillaService, @Value("${nextfeet.envio.costo}") BigDecimal costoEnvio) {
        this.pedidoDAO = pedidoDAO;
        this.direccionDAO = direccionDAO;
        this.carritoDAO = carritoDAO;
        this.zapatillaService = zapatillaService;
        this.costoEnvio = costoEnvio;
    }

    // ---------------------------------------------------------------- Interfaz 11
    @Override
    public int registrarDireccion(int idUsuario, Direccion direccion) {
        if (direccion.getCiudad() == null || direccion.getCiudad().isBlank()
                || direccion.getDistrito() == null || direccion.getDistrito().isBlank()
                || direccion.getDireccion() == null || direccion.getDireccion().isBlank()) {
            throw new NegocioException("Completa ciudad, distrito y dirección exacta.");
        }
        direccion.setIdUsuario(idUsuario);
        return direccionDAO.crear(direccion);
    }

    // ---------------------------------------------------------------- F16 / F17
    @Transactional
    @Override
    public Pedido confirmarCompra(int idUsuario, int idDireccion, PagoDTO pago) {
        validarPago(pago);
        Direccion direccion = direccionDAO.buscarPorId(idDireccion);
        if (direccion == null || direccion.getIdUsuario() != idUsuario) {
            throw new NegocioException("La dirección de envío no es válida.");
        }
        Carrito carrito = carritoDAO.obtenerCarrito(idUsuario);
        if (carrito.isVacio()) {
            throw new NegocioException("Tu carrito está vacío.");
        }

        // Última verificación de stock antes de descontar (evita condiciones de carrera).
        for (CarritoItem item : carrito.getItems()) {
            zapatillaService.verificarDisponibilidad(item.getIdZapatilla(), item.getTalla(), item.getCantidad());
        }

        BigDecimal subtotal = carrito.getTotal();
        BigDecimal total = subtotal.add(costoEnvio);

        Pedido pedido = new Pedido();
        pedido.setCodigo(generarCodigo());
        pedido.setIdUsuario(idUsuario);
        pedido.setIdDireccion(idDireccion);
        pedido.setFecha(LocalDateTime.now());
        pedido.setSubtotal(subtotal);
        pedido.setCostoEnvio(costoEnvio);
        pedido.setTotal(total);
        pedido.setEstado("PENDIENTE");
        pedido.setMetodoPago(pago.getMetodoPago());
        int idPedido = pedidoDAO.crear(pedido);
        pedidoDAO.registrarHistorial(idPedido, "PENDIENTE");

        for (CarritoItem item : carrito.getItems()) {
            DetallePedido detalle = new DetallePedido();
            detalle.setIdZapatilla(item.getIdZapatilla());
            detalle.setNombreZapatilla(item.getNombre());
            detalle.setTalla(item.getTalla());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(item.getPrecioUnitario());
            detalle.setSubtotal(item.getSubtotal());
            pedidoDAO.crearDetalle(idPedido, detalle);

            // Descuenta el inventario físico de cada variante comprada.
            ZapatillaTalla t = zapatillaService.verificarDisponibilidad(item.getIdZapatilla(), item.getTalla(), item.getCantidad());
            zapatillaService.actualizarStock(item.getIdZapatilla(), item.getTalla(),
                    t.getStock() - item.getCantidad(), "Venta pedido " + pedido.getCodigo());
        }

        carritoDAO.vaciar(carrito.getId());
        return pedidoDAO.buscarPorId(idPedido);
    }

    // ---------------------------------------------------------------- F18
    @Override
    public List<Pedido> historialCliente(int idUsuario) {
        return pedidoDAO.listarPorCliente(idUsuario);
    }

    // ---------------------------------------------------------------- F19
    @Override
    public Pedido detalleCliente(int idUsuario, int idPedido) {
        Pedido p = detalleAdmin(idPedido);
        if (p.getIdUsuario() != idUsuario) {
            throw new NegocioException("El pedido no pertenece a tu cuenta.");
        }
        return p;
    }

    // ---------------------------------------------------------------- F20
    @Override
    public Pedido seguimiento(int idUsuario, int idPedido) {
        return detalleCliente(idUsuario, idPedido);
    }

    // ---------------------------------------------------------------- F39
    @Override
    public Pagina<Pedido> listarGlobal(String estado, String busqueda, int pagina) {
        return pedidoDAO.listarGlobal(estado, busqueda, pagina, TAMANO_PAGINA);
    }

    @Override
    public Pedido detalleAdmin(int idPedido) {
        Pedido p = pedidoDAO.buscarPorId(idPedido);
        if (p == null) {
            throw new NegocioException("El pedido no existe.");
        }
        return p;
    }

    // ---------------------------------------------------------------- F40
    @Override
    public void actualizarEstado(int idPedido, String nuevoEstado) {
        Pedido p = detalleAdmin(idPedido);
        if ("ANULADO".equals(p.getEstado()) || "REEMBOLSADO".equals(p.getEstado())) {
            throw new NegocioException("El pedido ya está finalizado y no puede cambiar de estado.");
        }
        if (!FLUJO_ESTADOS.contains(nuevoEstado) && !"REEMBOLSADO".equals(nuevoEstado)) {
            throw new NegocioException("Estado de pedido no reconocido.");
        }
        if (FLUJO_ESTADOS.contains(nuevoEstado)) {
            int actual = FLUJO_ESTADOS.indexOf(p.getEstado());
            int nuevo = FLUJO_ESTADOS.indexOf(nuevoEstado);
            if (nuevo < actual) {
                throw new NegocioException("No se puede retroceder el estado del pedido.");
            }
        }
        pedidoDAO.actualizarEstado(idPedido, nuevoEstado);
    }

    // ---------------------------------------------------------------- F41
    @Transactional
    @Override
    public void anular(int idPedido, String motivo) {
        Pedido p = detalleAdmin(idPedido);
        if ("ANULADO".equals(p.getEstado())) {
            throw new NegocioException("El pedido ya se encuentra anulado.");
        }
        if ("ENTREGADO".equals(p.getEstado())) {
            throw new NegocioException("No se puede anular un pedido ya entregado.");
        }
        if (motivo == null || motivo.isBlank()) {
            throw new NegocioException("Indica el motivo de la anulación.");
        }
        // Reintegra al inventario cada unidad vendida en el pedido.
        for (DetallePedido d : p.getDetalles()) {
            ZapatillaTalla t = zapatillaService.verificarDisponibilidadSinLanzar(d.getIdZapatilla(), d.getTalla());
            int stockActual = t == null ? 0 : t.getStock();
            zapatillaService.actualizarStock(d.getIdZapatilla(), d.getTalla(), stockActual + d.getCantidad(),
                    "Anulación pedido " + p.getCodigo());
        }
        pedidoDAO.anular(idPedido, motivo);
    }

    private void validarPago(PagoDTO pago) {
        if (pago == null || pago.getMetodoPago() == null || pago.getMetodoPago().isBlank()) {
            throw new NegocioException("Selecciona un método de pago.");
        }
        if ("TARJETA".equals(pago.getMetodoPago())) {
            if (pago.getNumeroTarjeta() == null || pago.getNumeroTarjeta().replaceAll("\\s", "").length() < 12) {
                throw new NegocioException("El número de tarjeta no es válido.");
            }
            if (pago.getCvv() == null || !pago.getCvv().matches("\\d{3,4}")) {
                throw new NegocioException("El CVV no es válido.");
            }
        }
    }

    private String generarCodigo() {
        String codigo;
        do {
            codigo = "NF-" + System.currentTimeMillis();
        } while (pedidoDAO.existeCodigo(codigo));
        return codigo;
    }

}
