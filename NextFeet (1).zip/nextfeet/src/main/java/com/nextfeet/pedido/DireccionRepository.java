package com.nextfeet.pedido;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

@Repository
public class DireccionRepository implements DireccionDAO {

    private final JdbcTemplate jdbcTemplate;

    public DireccionRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private final RowMapper<Direccion> mapper = (rs, rowNum) -> {
        Direccion d = new Direccion();
        d.setId(rs.getInt("id"));
        d.setIdUsuario(rs.getInt("id_usuario"));
        d.setCiudad(rs.getString("ciudad"));
        d.setDistrito(rs.getString("distrito"));
        d.setDireccion(rs.getString("direccion"));
        d.setReferencia(rs.getString("referencia"));
        return d;
    };

    @Override
    public int crear(Direccion d) {
        SimpleJdbcInsert insert = new SimpleJdbcInsert(jdbcTemplate)
                .withTableName("direccion").usingGeneratedKeyColumns("id");
        Number key = insert.executeAndReturnKey(Map.of(
                "id_usuario", d.getIdUsuario(),
                "ciudad", d.getCiudad(),
                "distrito", d.getDistrito(),
                "direccion", d.getDireccion(),
                "referencia", d.getReferencia() == null ? "" : d.getReferencia()));
        return key.intValue();
    }

    @Override
    public Direccion buscarPorId(int id) {
        List<Direccion> r = jdbcTemplate.query(
                "SELECT id, id_usuario, ciudad, distrito, direccion, referencia FROM direccion WHERE id = ?",
                mapper, id);
        return r.isEmpty() ? null : r.get(0);
    }

}
