package com.nextfeet.carrito;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nextfeet.common.NegocioException;
import com.nextfeet.common.Sesion;

import jakarta.servlet.http.HttpSession;

/** Interfaz 10: carrito de compras (F11-F15). */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/carrito")
public class CarritoController {

    private final CarritoService carritoService;

    public CarritoController(CarritoService carritoService) {
        this.carritoService = carritoService;
    }

    // F12: visualizar carrito
    @GetMapping
    public String ver(HttpSession session, Model model) {
        model.addAttribute("carrito", carritoService.verCarrito(Sesion.idUsuario(session)));
        return "carrito/ver";
    }

    // F11: añadir al carrito
    @PostMapping("/agregar")
    public String agregar(HttpSession session, @RequestParam("idZapatilla") int idZapatilla,
            @RequestParam("talla") String talla, @RequestParam(value = "cantidad", defaultValue = "1") int cantidad,
            Model model) {
        try {
            carritoService.agregarItem(Sesion.idUsuario(session), idZapatilla, talla, cantidad);
            return "redirect:/carrito?agregado";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            return "redirect:/zapatilla/" + idZapatilla + "?error=" + ex.getMessage();
        }
    }

    // F13: modificar cantidad
    @PostMapping("/actualizar")
    public String actualizar(HttpSession session, @RequestParam("idZapatilla") int idZapatilla,
            @RequestParam("talla") String talla, @RequestParam("cantidad") int cantidad) {
        carritoService.actualizarCantidad(Sesion.idUsuario(session), idZapatilla, talla, cantidad);
        return "redirect:/carrito";
    }

    // F14: eliminar producto
    @PostMapping("/eliminar")
    public String eliminar(HttpSession session, @RequestParam("idZapatilla") int idZapatilla,
            @RequestParam("talla") String talla) {
        carritoService.eliminarItem(Sesion.idUsuario(session), idZapatilla, talla);
        return "redirect:/carrito";
    }

    // F15: vaciar carrito
    @PostMapping("/vaciar")
    public String vaciar(HttpSession session) {
        carritoService.vaciarCarrito(Sesion.idUsuario(session));
        return "redirect:/carrito";
    }

}
