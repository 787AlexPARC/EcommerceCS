package com.nextfeet.carrito;

public interface CarritoService {

    Carrito verCarrito(int idUsuario);                                             // F12

    void agregarItem(int idUsuario, int idZapatilla, String talla, int cantidad);   // F11

    void actualizarCantidad(int idUsuario, int idZapatilla, String talla, int cantidad); // F13

    void eliminarItem(int idUsuario, int idZapatilla, String talla);                // F14

    void vaciarCarrito(int idUsuario);                                             // F15

}
