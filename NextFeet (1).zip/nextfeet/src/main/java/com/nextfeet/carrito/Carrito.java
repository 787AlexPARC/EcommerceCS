package com.nextfeet.carrito;

import java.math.BigDecimal;
import java.util.List;

public class Carrito {

    private Integer id;
    private Integer idUsuario;
    private List<CarritoItem> items;

    public Carrito() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public List<CarritoItem> getItems() {
        return items;
    }

    public void setItems(List<CarritoItem> items) {
        this.items = items;
    }

    public BigDecimal getTotal() {
        BigDecimal total = BigDecimal.ZERO;
        if (items != null) {
            for (CarritoItem i : items) {
                total = total.add(i.getSubtotal());
            }
        }
        return total;
    }

    public int getCantidadTotal() {
        return items == null ? 0 : items.stream().mapToInt(CarritoItem::getCantidad).sum();
    }

    public boolean isVacio() {
        return items == null || items.isEmpty();
    }

}
