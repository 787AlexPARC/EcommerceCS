package com.nextfeet.categoria;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nextfeet.common.NegocioException;

/** Interfaz 26 (listado), Interfaz 27 (crear), Interfaz 28 (editar/desactivar). F29-F32. */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/admin/categorias")
public class AdminCategoriaController {

    private final CategoriaService categoriaService;

    public AdminCategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("categorias", categoriaService.listarTodas()); // F29
        return "admin/categorias/lista";
    }

    @GetMapping("/crear")
    public String formularioCrear(Model model) {
        model.addAttribute("categoria", new Categoria());
        return "admin/categorias/crear";
    }

    @PostMapping("/crear")
    public String crear(@RequestParam("nombre") String nombre,
            @RequestParam(value = "descripcion", required = false) String descripcion, Model model) {
        try {
            categoriaService.crear(nombre, descripcion); // F30
            return "redirect:/admin/categorias";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            return "admin/categorias/crear";
        }
    }

    @GetMapping("/{id}/editar")
    public String formularioEditar(@PathVariable int id, Model model) {
        model.addAttribute("categoria", categoriaService.obtener(id));
        return "admin/categorias/editar";
    }

    @PostMapping("/{id}/editar")
    public String editar(@PathVariable int id, @RequestParam("nombre") String nombre,
            @RequestParam(value = "descripcion", required = false) String descripcion, Model model) {
        try {
            categoriaService.actualizar(id, nombre, descripcion); // F31
            return "redirect:/admin/categorias";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("categoria", categoriaService.obtener(id));
            return "admin/categorias/editar";
        }
    }

    @PostMapping("/{id}/eliminar")
    public String desactivarOEliminar(@PathVariable int id) {
        categoriaService.desactivarOEliminar(id); // F32
        return "redirect:/admin/categorias";
    }

}
