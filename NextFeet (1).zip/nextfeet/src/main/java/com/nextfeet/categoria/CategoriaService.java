package com.nextfeet.categoria;

import java.util.List;

public interface CategoriaService {

    List<Categoria> listarTodas();                      // F29

    Categoria obtener(int id);

    void crear(String nombre, String descripcion);       // F30

    void actualizar(int id, String nombre, String descripcion); // F31

    void desactivarOEliminar(int id);                    // F32

}
