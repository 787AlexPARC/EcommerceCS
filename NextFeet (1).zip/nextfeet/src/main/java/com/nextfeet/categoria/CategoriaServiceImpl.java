package com.nextfeet.categoria;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nextfeet.common.NegocioException;

@Service
public class CategoriaServiceImpl implements CategoriaService {

    private final CategoriaDAO categoriaDAO;

    public CategoriaServiceImpl(CategoriaDAO categoriaDAO) {
        this.categoriaDAO = categoriaDAO;
    }

    // ---------------------------------------------------------------- F29
    @Override
    public List<Categoria> listarTodas() {
        return categoriaDAO.listarTodas();
    }

    @Override
    public Categoria obtener(int id) {
        Categoria c = categoriaDAO.buscarPorId(id);
        if (c == null) {
            throw new NegocioException("La categoría no existe.");
        }
        return c;
    }

    // ---------------------------------------------------------------- F30
    @Override
    public void crear(String nombre, String descripcion) {
        validarNombre(nombre);
        if (categoriaDAO.buscarPorNombre(nombre) != null) {
            throw new NegocioException("Ya existe una categoría con ese nombre.");
        }
        Categoria c = new Categoria();
        c.setNombre(nombre.trim());
        c.setDescripcion(descripcion);
        categoriaDAO.crear(c);
    }

    // ---------------------------------------------------------------- F31
    @Override
    public void actualizar(int id, String nombre, String descripcion) {
        Categoria c = obtener(id);
        validarNombre(nombre);
        Categoria existente = categoriaDAO.buscarPorNombre(nombre);
        if (existente != null && !existente.getId().equals(id)) {
            throw new NegocioException("Ya existe una categoría con ese nombre.");
        }
        c.setNombre(nombre.trim());
        c.setDescripcion(descripcion);
        categoriaDAO.actualizar(c);
    }

    // ---------------------------------------------------------------- F32
    @Override
    public void desactivarOEliminar(int id) {
        Categoria c = obtener(id);
        long total = categoriaDAO.contarZapatillas(id);
        if (total == 0) {
            // Sin zapatillas asociadas: se asume creada por error y puede eliminarse.
            categoriaDAO.eliminar(id);
        } else {
            categoriaDAO.cambiarEstado(id, !c.isActivo());
        }
    }

    private void validarNombre(String nombre) {
        if (nombre == null || nombre.isBlank()) {
            throw new NegocioException("El nombre de la categoría es obligatorio.");
        }
    }

}
