package com.nextfeet.usuario;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;

import com.nextfeet.common.NegocioException;
import com.nextfeet.common.Sesion;

import jakarta.servlet.http.HttpSession;

/** Interfaz 03: perfil del cliente (F03, F04, F05). */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/perfil")
public class PerfilClienteController {

    private final UsuarioService usuarioService;

    public PerfilClienteController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public String verPerfil(HttpSession session, Model model) {
        model.addAttribute("usuario", usuarioService.obtenerPerfil(Sesion.idUsuario(session))); // F03
        return "perfil/ver";
    }

    @PostMapping("/actualizar")
    public String actualizar(HttpSession session,
            @RequestParam("nombres") String nombres, @RequestParam("apellidos") String apellidos,
            @RequestParam("telefono") String telefono,
            @RequestParam(value = "nuevaPassword", required = false) String nuevaPassword,
            Model model) {
        try {
            usuarioService.actualizarPerfil(Sesion.idUsuario(session), nombres, apellidos, telefono, nuevaPassword); // F04
            return "redirect:/perfil?actualizado";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("usuario", usuarioService.obtenerPerfil(Sesion.idUsuario(session)));
            return "perfil/ver";
        }
    }

    @PostMapping("/desactivar")
    public String desactivar(HttpSession session, @RequestParam("passwordActual") String passwordActual,
            Model model) {
        try {
            usuarioService.desactivarCuentaPropia(Sesion.idUsuario(session), passwordActual); // F05
            session.invalidate();
            return "redirect:/login?desactivado";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("usuario", usuarioService.obtenerPerfil(Sesion.idUsuario(session)));
            return "perfil/ver";
        }
    }

}
