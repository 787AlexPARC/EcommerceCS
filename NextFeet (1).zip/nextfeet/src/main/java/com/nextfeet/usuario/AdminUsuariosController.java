package com.nextfeet.usuario;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nextfeet.common.NegocioException;
import com.nextfeet.common.Sesion;

import jakarta.servlet.http.HttpSession;

/**
 * Interfaz 17/18 (panel), Interfaz 19 (crear admin), Interfaz 22 (desactivar admin),
 * Interfaz 23 (listar clientes), Interfaz 24 (editar cliente), Interfaz 25 (desactivar cliente).
 */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/admin")
public class AdminUsuariosController {

    private final UsuarioService usuarioService;

    public AdminUsuariosController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public String panel() {
        return "admin/panel"; // Interfaz 17
    }

    // ---- Administradores ----
    @GetMapping("/administradores")
    public String listarAdmins(Model model) {
        model.addAttribute("administradores", usuarioService.listarAdministradores()); // F21
        return "admin/administradores/lista";
    }

    @GetMapping("/administradores/crear")
    public String formularioCrearAdmin(Model model) {
        model.addAttribute("registro", new RegistroDTO());
        return "admin/administradores/crear";
    }

    @PostMapping("/administradores/crear")
    public String crearAdmin(@ModelAttribute("registro") RegistroDTO dto, Model model) {
        try {
            usuarioService.registrarAdministrador(dto); // F22
            return "redirect:/admin/administradores";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            return "admin/administradores/crear";
        }
    }

    @PostMapping("/administradores/{id}/desactivar")
    public String desactivarAdmin(@PathVariable int id, HttpSession session, Model model) {
        try {
            usuarioService.desactivarAdministrador(id, Sesion.idUsuario(session)); // F25
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
        }
        return "redirect:/admin/administradores";
    }

    // ---- Clientes ----
    @GetMapping("/clientes")
    public String listarClientes(@RequestParam(value = "q", required = false) String q,
            @RequestParam(value = "activo", required = false) Boolean activo,
            @RequestParam(value = "pagina", defaultValue = "1") int pagina, Model model) {
        model.addAttribute("resultado", usuarioService.listarClientes(q, activo, pagina)); // F26
        model.addAttribute("q", q);
        model.addAttribute("activo", activo);
        return "admin/clientes/lista";
    }

    @GetMapping("/clientes/{id}/editar")
    public String formularioEditarCliente(@PathVariable int id, Model model) {
        model.addAttribute("cliente", usuarioService.obtenerPerfil(id));
        return "admin/clientes/editar";
    }

    @PostMapping("/clientes/{id}/editar")
    public String editarCliente(@PathVariable int id, @RequestParam("nombres") String nombres,
            @RequestParam("apellidos") String apellidos, @RequestParam("telefono") String telefono, Model model) {
        try {
            usuarioService.actualizarCliente(id, nombres, apellidos, telefono); // F27
            return "redirect:/admin/clientes";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("cliente", usuarioService.obtenerPerfil(id));
            return "admin/clientes/editar";
        }
    }

    @PostMapping("/clientes/{id}/desactivar")
    public String desactivarCliente(@PathVariable int id) {
        usuarioService.desactivarCliente(id); // F28
        return "redirect:/admin/clientes";
    }

}
