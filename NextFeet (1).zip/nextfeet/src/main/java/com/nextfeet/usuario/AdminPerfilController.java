package com.nextfeet.usuario;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nextfeet.common.NegocioException;
import com.nextfeet.common.Sesion;

import jakarta.servlet.http.HttpSession;

/** Interfaz 20 (ver perfil admin), Interfaz 21 (editar), Interfaz 22 (desactivar). F23/F24/F25. */
@Controller
@org.springframework.web.bind.annotation.RequestMapping("/admin/perfil")
public class AdminPerfilController {

    private final UsuarioService usuarioService;

    public AdminPerfilController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public String ver(HttpSession session, Model model) {
        model.addAttribute("usuario", usuarioService.obtenerPerfil(Sesion.idUsuario(session))); // F23
        return "admin/perfil";
    }

    @PostMapping("/actualizar")
    public String actualizar(HttpSession session, @RequestParam("nombres") String nombres,
            @RequestParam("apellidos") String apellidos, @RequestParam("telefono") String telefono,
            @RequestParam(value = "nuevaPassword", required = false) String nuevaPassword, Model model) {
        try {
            usuarioService.actualizarPerfil(Sesion.idUsuario(session), nombres, apellidos, telefono, nuevaPassword); // F24
            return "redirect:/admin/perfil?actualizado";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("usuario", usuarioService.obtenerPerfil(Sesion.idUsuario(session)));
            return "admin/perfil";
        }
    }

    @PostMapping("/desactivar")
    public String desactivarPropia(HttpSession session, @RequestParam("passwordActual") String passwordActual,
            Model model) {
        try {
            usuarioService.desactivarCuentaPropia(Sesion.idUsuario(session), passwordActual);
            session.invalidate();
            return "redirect:/login?desactivado";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            model.addAttribute("usuario", usuarioService.obtenerPerfil(Sesion.idUsuario(session)));
            return "admin/perfil";
        }
    }

}
