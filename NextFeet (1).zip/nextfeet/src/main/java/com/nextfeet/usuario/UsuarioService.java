package com.nextfeet.usuario;

import java.util.List;

import com.nextfeet.common.Pagina;

public interface UsuarioService {

    // Módulo 1: autenticación y cuenta de cliente
    Usuario iniciarSesion(String correo, String password);                                   // F01

    void registrarCliente(RegistroDTO dto);                                                  // F02

    Usuario obtenerPerfil(int idUsuario);                                                    // F03 / F23

    void actualizarPerfil(int idUsuario, String nombres, String apellidos, String telefono,
            String nuevaPassword);                                                           // F04 / F24

    void desactivarCuentaPropia(int idUsuario, String passwordActual);                       // F05

    // Módulo 5: administración de usuarios
    List<Usuario> listarAdministradores();                                                   // F21

    void registrarAdministrador(RegistroDTO dto);                                            // F22

    void desactivarAdministrador(int idObjetivo, int idAdminEnSesion);                       // F25

    Pagina<Usuario> listarClientes(String busqueda, Boolean activo, int pagina);             // F26

    void actualizarCliente(int idCliente, String nombres, String apellidos, String telefono); // F27

    void desactivarCliente(int idCliente);                                                   // F28

}
