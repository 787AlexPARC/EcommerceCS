package com.nextfeet.usuario;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;

import com.nextfeet.common.NegocioException;
import com.nextfeet.common.Sesion;

import jakarta.servlet.http.HttpSession;

/** Interfaz 01 (login) e Interfaz 02 (registro de cliente). */
@Controller
public class AuthController {

    private final UsuarioService usuarioService;

    public AuthController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/login")
    public String mostrarLogin(HttpSession session) {
        if (Sesion.usuario(session) != null) {
            return "redirect:/";
        }
        return "auth/login";
    }

    // F01: iniciar sesión
    @PostMapping("/login")
    public String iniciarSesion(@RequestParam("correo") String correo,
            @RequestParam("password") String password, HttpSession session, Model model) {
        try {
            Usuario usuario = usuarioService.iniciarSesion(correo, password);
            session.setAttribute(Sesion.USUARIO, usuario);
            return usuario.isAdmin() ? "redirect:/admin" : "redirect:/";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            return "auth/login";
        }
    }

    @GetMapping("/logout")
    public String cerrarSesion(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
        model.addAttribute("registro", new RegistroDTO());
        return "auth/registro";
    }

    // F02: registrar nuevo cliente
    @PostMapping("/registro")
    public String registrar(@ModelAttribute("registro") RegistroDTO dto, Model model) {
        try {
            usuarioService.registrarCliente(dto);
            return "redirect:/login?registrado";
        } catch (NegocioException ex) {
            model.addAttribute("error", ex.getMessage());
            return "auth/registro";
        }
    }

}
