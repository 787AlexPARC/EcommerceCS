package com.nextfeet.common;

public class StockInsuficienteException extends NegocioException {

    public StockInsuficienteException(String mensaje) {
        super(mensaje);
    }

}
