package com.nextfeet.common;

/** Error de regla de negocio: el mensaje es apto para mostrarse al usuario. */
public class NegocioException extends RuntimeException {

    public NegocioException(String mensaje) {
        super(mensaje);
    }

}
