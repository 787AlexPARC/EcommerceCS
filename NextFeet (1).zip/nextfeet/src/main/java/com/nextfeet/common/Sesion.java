package com.nextfeet.common;

import com.nextfeet.usuario.Usuario;

import jakarta.servlet.http.HttpSession;

/** Utilidades para el usuario autenticado guardado en la sesión HTTP. */
public final class Sesion {

    public static final String USUARIO = "usuario";

    private Sesion() {
    }

    public static Usuario usuario(HttpSession session) {
        return (Usuario) session.getAttribute(USUARIO);
    }

    public static int idUsuario(HttpSession session) {
        return usuario(session).getId();
    }

}
