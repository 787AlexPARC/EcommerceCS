<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="titulo" value="Ofertas - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/admin-header.jsp" />

<!-- Interfaz 36: panel y listado general de ofertas -->
<div class="fila" style="justify-content:space-between;align-items:center;">
    <h2>Ofertas y promociones</h2>
    <a class="btn btn-acento" href="/admin/ofertas/nueva">+ Nueva oferta</a>
</div>

<table>
    <thead><tr><th>Nombre</th><th>Descuento</th><th>Productos</th><th>Vigencia</th><th>Estado</th><th></th></tr></thead>
    <tbody>
    <c:forEach items="${ofertas}" var="o">
        <tr>
            <td>${o.nombre}</td>
            <td>${o.tipoDescuento == 'PORCENTAJE' ? o.valor.concat('%') : 'S/ '.concat(o.valor)}</td>
            <td>${o.totalProductos}</td>
            <td>${o.fechaInicio} - ${o.fechaFin}</td>
            <td><span class="badge-estado">${o.estado}</span></td>
            <td><a class="btn btn-pequeno btn-secundario" href="/admin/ofertas/${o.id}/editar">Gestionar</a></td>
        </tr>
    </c:forEach>
    <c:if test="${empty ofertas}"><tr><td colspan="6">No hay ofertas registradas.</td></tr></c:if>
    </tbody>
</table>

<jsp:include page="/WEB-INF/views/layout/admin-footer.jsp" />
