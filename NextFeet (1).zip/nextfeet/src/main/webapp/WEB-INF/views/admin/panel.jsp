<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="titulo" value="Panel administrativo - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/admin-header.jsp" />

<!-- Interfaz 17: panel de administración principal -->
<h2>Panel de administración</h2>
<div class="panel-admin-grilla">
    <a class="panel-admin-tile" href="/admin/categorias">📁 Categorías</a>
    <a class="panel-admin-tile" href="/admin/zapatillas">👟 Zapatillas</a>
    <a class="panel-admin-tile" href="/admin/ofertas">🏷️ Ofertas</a>
    <a class="panel-admin-tile" href="/admin/pedidos">📦 Pedidos</a>
    <a class="panel-admin-tile" href="/admin/clientes">👤 Clientes</a>
    <a class="panel-admin-tile" href="/admin/administradores">🛡️ Administradores</a>
</div>

<jsp:include page="/WEB-INF/views/layout/admin-footer.jsp" />
