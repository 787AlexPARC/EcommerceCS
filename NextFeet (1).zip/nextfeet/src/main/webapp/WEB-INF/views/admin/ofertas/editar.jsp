<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="titulo" value="Editar oferta - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/admin-header.jsp" />

<!-- Interfaz 38: modificación y desactivación/eliminación de oferta -->
<h2>Gestionar oferta: ${oferta.nombre}</h2>
<c:if test="${not empty error}"><div class="alerta alerta-error">${error}</div></c:if>

<form class="vertical" method="post" action="/admin/ofertas/${oferta.id}/editar" style="max-width:640px;">
    <label>Nombre de la campaña</label>
    <input name="nombre" value="${oferta.nombre}" required>
    <div class="fila">
        <div>
            <label>Tipo de descuento</label>
            <select name="tipoDescuento" required>
                <option value="PORCENTAJE" ${oferta.tipoDescuento == 'PORCENTAJE' ? 'selected' : ''}>Porcentaje (%)</option>
                <option value="MONTO" ${oferta.tipoDescuento == 'MONTO' ? 'selected' : ''}>Monto fijo (S/)</option>
            </select>
        </div>
        <div><label>Valor del descuento</label><input type="number" step="0.01" name="valor" value="${oferta.valor}" required></div>
    </div>
    <div class="fila">
        <div><label>Fecha de inicio</label><input type="date" name="fechaInicio" value="${oferta.fechaInicio}" required></div>
        <div><label>Fecha de fin</label><input type="date" name="fechaFin" value="${oferta.fechaFin}" required></div>
    </div>

    <label>Categorías afectadas</label>
    <select name="categoriaIds" multiple size="4">
        <c:forEach items="${categorias}" var="c">
            <option value="${c.id}" ${oferta.categoriaIds.contains(c.id) ? 'selected' : ''}>${c.nombre}</option>
        </c:forEach>
    </select>

    <label>Zapatillas afectadas</label>
    <select name="zapatillaIds" multiple size="6">
        <c:forEach items="${zapatillas}" var="z">
            <option value="${z.id}" ${oferta.zapatillaIds.contains(z.id) ? 'selected' : ''}>${z.marca} ${z.nombre}</option>
        </c:forEach>
    </select>

    <button class="btn" type="submit">Guardar modificaciones</button>
</form>

<div class="zona-peligro" style="max-width:640px;">
    <h4>Zona de peligro</h4>
    <p>Finaliza esta oferta antes de tiempo. Los productos volverán a su precio de lista.</p>
    <form method="post" action="/admin/ofertas/${oferta.id}/desactivar" onsubmit="return confirm('¿Desactivar esta oferta ahora?');">
        <button class="btn btn-peligro" type="submit">Desactivar oferta</button>
    </form>
</div>

<jsp:include page="/WEB-INF/views/layout/admin-footer.jsp" />
