<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="titulo" value="Nueva oferta - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/admin-header.jsp" />

<!-- Interfaz 37: creación y asignación de oferta -->
<h2>Nueva oferta</h2>
<c:if test="${not empty error}"><div class="alerta alerta-error">${error}</div></c:if>

<form class="vertical" method="post" action="/admin/ofertas/nueva" style="max-width:640px;">
    <label>Nombre de la campaña</label>
    <input name="nombre" required>
    <div class="fila">
        <div>
            <label>Tipo de descuento</label>
            <select name="tipoDescuento" required>
                <option value="PORCENTAJE">Porcentaje (%)</option>
                <option value="MONTO">Monto fijo (S/)</option>
            </select>
        </div>
        <div><label>Valor del descuento</label><input type="number" step="0.01" name="valor" required></div>
    </div>
    <div class="fila">
        <div><label>Fecha de inicio</label><input type="date" name="fechaInicio" required></div>
        <div><label>Fecha de fin</label><input type="date" name="fechaFin" required></div>
    </div>

    <label>Categorías afectadas</label>
    <select name="categoriaIds" multiple size="4">
        <c:forEach items="${categorias}" var="c"><option value="${c.id}">${c.nombre}</option></c:forEach>
    </select>

    <label>Zapatillas afectadas</label>
    <select name="zapatillaIds" multiple size="6">
        <c:forEach items="${zapatillas}" var="z"><option value="${z.id}">${z.marca} ${z.nombre}</option></c:forEach>
    </select>
    <small>Mantén presionado Ctrl (o Cmd en Mac) para seleccionar varias opciones.</small>

    <button class="btn btn-acento" type="submit">Guardar y asignar</button>
</form>

<jsp:include page="/WEB-INF/views/layout/admin-footer.jsp" />
