<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form" %>
<c:set var="titulo" value="Dirección de envío - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/header.jsp" />

<!-- Interfaz 11: dirección de envío -->
<div class="tabs"><a class="activo">1. Dirección</a><a>2. Pago</a><a>3. Comprobante</a></div>
<h2>Dirección de envío</h2>
<c:if test="${not empty error}"><div class="alerta alerta-error">${error}</div></c:if>

<form:form class="vertical" modelAttribute="direccion" method="post" action="/checkout/direccion">
    <label>Ciudad</label>
    <form:input path="ciudad" required="true" />
    <label>Distrito</label>
    <form:input path="distrito" required="true" />
    <label>Dirección exacta</label>
    <form:input path="direccion" required="true" />
    <label>Referencia</label>
    <form:input path="referencia" />
    <button class="btn btn-acento" type="submit">Confirmar dirección</button>
</form:form>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
