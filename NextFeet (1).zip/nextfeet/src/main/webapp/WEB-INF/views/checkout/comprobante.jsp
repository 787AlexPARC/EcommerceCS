<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="titulo" value="Comprobante - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/header.jsp" />

<!-- Interfaz 13: comprobante de pago -->
<div class="tabs"><a>1. Dirección</a><a>2. Pago</a><a class="activo">3. Comprobante</a></div>
<div class="tarjeta" style="max-width:600px;">
    <h2>¡Compra realizada con éxito!</h2>
    <p><strong>Código de pedido:</strong> ${pedido.codigo}</p>
    <p><strong>Fecha:</strong> ${pedido.fechaTexto}</p>
    <table>
        <thead><tr><th>Producto</th><th>Talla</th><th>Cant.</th><th>Subtotal</th></tr></thead>
        <tbody>
        <c:forEach items="${pedido.detalles}" var="d">
            <tr><td>${d.nombreZapatilla}</td><td>${d.talla}</td><td>${d.cantidad}</td><td>S/ ${d.subtotal}</td></tr>
        </c:forEach>
        </tbody>
    </table>
    <p>Subtotal: S/ ${pedido.subtotal}</p>
    <p>Envío: S/ ${pedido.costoEnvio}</p>
    <p style="font-size:1.2rem;"><strong>Total pagado: S/ ${pedido.total}</strong></p>
    <div class="fila">
        <a class="btn" href="/mis-pedidos/${pedido.id}">Ver detalle del pedido</a>
        <button class="btn btn-secundario" onclick="window.print()">Descargar / Imprimir</button>
    </div>
</div>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
