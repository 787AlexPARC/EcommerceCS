<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form" %>
<c:set var="titulo" value="Pago - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/header.jsp" />

<!-- Interfaz 12: simulación de pago -->
<div class="tabs"><a>1. Dirección</a><a class="activo">2. Pago</a><a>3. Comprobante</a></div>
<h2>Selecciona tu método de pago</h2>
<c:if test="${not empty error}"><div class="alerta alerta-error">${error}</div></c:if>

<form:form class="vertical" modelAttribute="pago" method="post" action="/checkout/pago">
    <input type="hidden" name="idDireccion" value="${idDireccion}">
    <label>Método de pago</label>
    <select name="metodoPago" required>
        <option value="TARJETA">Tarjeta de crédito/débito</option>
        <option value="YAPE_PLIN">Yape / Plin</option>
        <option value="TRANSFERENCIA">Transferencia bancaria</option>
    </select>
    <fieldset style="border:1px solid #dfe3e8;border-radius:6px;padding:12px;">
        <legend>Datos simulados de tarjeta</legend>
        <label>Número de tarjeta</label>
        <input type="text" name="numeroTarjeta" placeholder="•••• •••• •••• ••••" maxlength="19">
        <div class="fila">
            <div><label>CVV</label><input type="text" name="cvv" maxlength="4"></div>
            <div><label>Vencimiento</label><input type="text" name="expiracion" placeholder="MM/AA"></div>
        </div>
    </fieldset>
    <button class="btn btn-acento" type="submit">Pagar ahora</button>
</form:form>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
