</main>
<footer class="nf-footer">
    <div class="contenedor">
        <div>
            <strong>NextFeet</strong>
            <p>E-commerce de zapatillas para emprendedores digitales.</p>
        </div>
        <div>
            <a href="/nosotros">Nosotros</a><br>
            <a href="/contacto">Contacto</a><br>
            <a href="/ofertas">Ofertas</a>
        </div>
        <div>&copy; 2026 NextFeet. Todos los derechos reservados.</div>
    </div>
</footer>
</body>
</html>
