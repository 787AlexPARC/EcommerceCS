<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="titulo" value="Pedido ${pedido.codigo} - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/header.jsp" />

<!-- Interfaz 14: detalle del pedido -->
<h2>Pedido ${pedido.codigo}</h2>
<p><span class="badge-estado estado-${pedido.estado}">${pedido.estadoTexto}</span>
   &nbsp; <a href="/mis-pedidos/${pedido.id}/seguimiento">Ver seguimiento de envío</a></p>

<div class="fila" style="align-items:flex-start;">
    <div class="tarjeta" style="flex:1;">
        <h4>Dirección de envío</h4>
        <p>${pedido.direccionEnvio.direccion}, ${pedido.direccionEnvio.distrito}, ${pedido.direccionEnvio.ciudad}</p>
        <p>${pedido.direccionEnvio.referencia}</p>
        <p><strong>Costo de envío:</strong> S/ ${pedido.costoEnvio}</p>
    </div>
    <div class="tarjeta" style="flex:2;">
        <h4>Productos</h4>
        <table>
            <thead><tr><th>Zapatilla</th><th>Talla</th><th>Cant.</th><th>Subtotal</th></tr></thead>
            <tbody>
            <c:forEach items="${pedido.detalles}" var="d">
                <tr><td>${d.nombreZapatilla}</td><td>${d.talla}</td><td>${d.cantidad}</td><td>S/ ${d.subtotal}</td></tr>
            </c:forEach>
            </tbody>
        </table>
        <p style="text-align:right;font-size:1.1rem;"><strong>Total: S/ ${pedido.total}</strong></p>
    </div>
</div>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
