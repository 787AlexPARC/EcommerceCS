<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="titulo" value="Carrito - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/header.jsp" />

<!-- Interfaz 10: carrito de compras -->
<h2>Carrito de compras</h2>
<c:if test="${param.agregado != null}"><div class="alerta alerta-exito">Producto añadido al carrito.</div></c:if>

<c:choose>
<c:when test="${carrito.vacio}">
    <p>Tu carrito está vacío. <a href="/catalogo">Ir al catálogo</a></p>
</c:when>
<c:otherwise>
<table>
    <thead><tr><th>Producto</th><th>Talla</th><th>Precio</th><th>Cantidad</th><th>Subtotal</th><th></th></tr></thead>
    <tbody>
    <c:forEach items="${carrito.items}" var="i">
        <tr>
            <td style="display:flex;gap:10px;align-items:center;">
                <img src="${i.imagenUrl}" style="width:50px;height:50px;object-fit:cover;border-radius:4px;">
                ${i.marca} ${i.nombre}
            </td>
            <td>${i.talla}</td>
            <td>S/ ${i.precioUnitario}</td>
            <td>
                <form method="post" action="/carrito/actualizar" style="display:flex;gap:6px;">
                    <input type="hidden" name="idZapatilla" value="${i.idZapatilla}">
                    <input type="hidden" name="talla" value="${i.talla}">
                    <input type="number" name="cantidad" value="${i.cantidad}" min="1" max="${i.stockDisponible}" style="width:70px;">
                    <button class="btn btn-pequeno btn-secundario" type="submit">Actualizar</button>
                </form>
            </td>
            <td>S/ ${i.subtotal}</td>
            <td>
                <form method="post" action="/carrito/eliminar">
                    <input type="hidden" name="idZapatilla" value="${i.idZapatilla}">
                    <input type="hidden" name="talla" value="${i.talla}">
                    <button class="btn btn-pequeno btn-peligro" type="submit">Eliminar</button>
                </form>
            </td>
        </tr>
    </c:forEach>
    </tbody>
</table>

<div class="fila" style="justify-content:space-between;margin-top:16px;align-items:center;">
    <form method="post" action="/carrito/vaciar" onsubmit="return confirm('¿Vaciar todo el carrito?');">
        <button class="btn btn-peligro" type="submit">Vaciar carrito</button>
    </form>
    <div style="text-align:right;">
        <p style="font-size:1.2rem;">Total: <strong>S/ ${carrito.total}</strong></p>
        <a class="btn btn-acento" href="/checkout/direccion">Proceder al pago</a>
    </div>
</div>
</c:otherwise>
</c:choose>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
