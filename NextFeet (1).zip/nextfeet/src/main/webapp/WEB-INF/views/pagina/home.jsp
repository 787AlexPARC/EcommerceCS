<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="titulo" value="NextFeet - Zapatillas para cada paso" scope="request" />
<jsp:include page="/WEB-INF/views/layout/header.jsp" />

<!-- Interfaz 09 [estático]: banner publicitario de inicio -->
<div class="tarjeta" style="background:linear-gradient(90deg,#1a2b4c,#2b4374);color:#fff;text-align:center;padding:50px 20px;">
    <h1 style="margin:0 0 10px;">Pisa fuerte con NextFeet</h1>
    <p style="margin:0 0 20px;">Las mejores zapatillas de running, urbanas y básquet, a un clic de distancia.</p>
    <a class="btn btn-acento" href="/catalogo">Ver catálogo</a>
</div>

<c:if test="${not empty destacadas}">
<h2 style="margin-top:36px;">Ofertas destacadas</h2>
<div class="grilla">
    <c:forEach items="${destacadas}" var="z" begin="0" end="3">
        <div class="producto-card">
            <img src="${z.imagenUrl}" alt="${z.nombre}">
            <div class="cuerpo">
                <span class="marca">${z.marca}</span>
                <span class="nombre">${z.nombre}</span>
                <span class="badge-descuento">-${z.porcentajeDescuento}%</span>
                <span class="precio"><span class="precio-anterior">S/ ${z.precio}</span>S/ ${z.precioFinal}</span>
                <a class="btn btn-pequeno" href="/zapatilla/${z.id}">Ver producto</a>
            </div>
        </div>
    </c:forEach>
</div>
</c:if>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
