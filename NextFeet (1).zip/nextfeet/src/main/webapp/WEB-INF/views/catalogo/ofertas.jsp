<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<c:set var="titulo" value="Ofertas - NextFeet" scope="request" />
<jsp:include page="/WEB-INF/views/layout/header.jsp" />

<!-- Interfaz 05: zapatillas en oferta -->
<h2>Ofertas y promociones</h2>
<div class="grilla">
    <c:forEach items="${zapatillas}" var="z">
        <div class="producto-card">
            <img src="${z.imagenUrl}" alt="${z.nombre}">
            <div class="cuerpo">
                <span class="badge-descuento">-${z.porcentajeDescuento}% · ${z.ofertaNombre}</span>
                <span class="marca">${z.marca}</span>
                <span class="nombre">${z.nombre}</span>
                <span class="precio"><span class="precio-anterior">S/ ${z.precio}</span>S/ ${z.precioFinal}</span>
                <a class="btn btn-pequeno" href="/zapatilla/${z.id}">Ver producto</a>
            </div>
        </div>
    </c:forEach>
    <c:if test="${empty zapatillas}"><p>No hay ofertas vigentes en este momento.</p></c:if>
</div>

<jsp:include page="/WEB-INF/views/layout/footer.jsp" />
