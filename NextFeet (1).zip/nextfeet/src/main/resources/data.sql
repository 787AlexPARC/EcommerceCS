-- Los usuarios (admin y cliente de prueba) se crean en config/DataInitializer para cifrar la contraseña.

INSERT INTO categoria (nombre, descripcion, activo) VALUES ('Running', 'Zapatillas para correr y entrenar', TRUE);
INSERT INTO categoria (nombre, descripcion, activo) VALUES ('Urbanas', 'Estilo urbano para el día a día', TRUE);
INSERT INTO categoria (nombre, descripcion, activo) VALUES ('Basketball', 'Zapatillas de alto rendimiento para básquet', TRUE);
INSERT INTO categoria (nombre, descripcion, activo) VALUES ('Casuales', 'Comodidad y diseño clásico', TRUE);

INSERT INTO zapatilla (sku, nombre, marca, descripcion, materiales, color, precio, imagen_url, id_categoria, activo, fecha_creacion)
VALUES ('NF-RUN-001', 'AirRun Pro', 'Nike', 'Zapatilla ligera con gran amortiguación para largas distancias.', 'Malla transpirable, EVA', 'Negro', 329.90, '/img/placeholder.svg', 1, TRUE, '2026-08-01');
INSERT INTO zapatilla (sku, nombre, marca, descripcion, materiales, color, precio, imagen_url, id_categoria, activo, fecha_creacion)
VALUES ('NF-RUN-002', 'UltraBoost Lite', 'Adidas', 'Retorno de energía en cada pisada.', 'Primeknit, Boost', 'Blanco', 459.00, '/img/placeholder.svg', 1, TRUE, '2026-08-03');
INSERT INTO zapatilla (sku, nombre, marca, descripcion, materiales, color, precio, imagen_url, id_categoria, activo, fecha_creacion)
VALUES ('NF-URB-001', 'Street Classic', 'Puma', 'Diseño urbano versátil.', 'Cuero sintético, goma', 'Gris', 249.50, '/img/placeholder.svg', 2, TRUE, '2026-08-05');
INSERT INTO zapatilla (sku, nombre, marca, descripcion, materiales, color, precio, imagen_url, id_categoria, activo, fecha_creacion)
VALUES ('NF-URB-002', 'Downtown Low', 'Converse', 'Clásica de lona de corte bajo.', 'Lona, goma vulcanizada', 'Rojo', 219.00, '/img/placeholder.svg', 2, TRUE, '2026-08-07');
INSERT INTO zapatilla (sku, nombre, marca, descripcion, materiales, color, precio, imagen_url, id_categoria, activo, fecha_creacion)
VALUES ('NF-BAS-001', 'CourtKing 2', 'Nike', 'Soporte de tobillo y tracción superior en cancha.', 'Sintético, espuma Zoom', 'Azul', 389.00, '/img/placeholder.svg', 3, TRUE, '2026-08-10');
INSERT INTO zapatilla (sku, nombre, marca, descripcion, materiales, color, precio, imagen_url, id_categoria, activo, fecha_creacion)
VALUES ('NF-CAS-001', 'Comfort Walk', 'Skechers', 'Plantilla memory foam para uso diario.', 'Malla, memory foam', 'Azul marino', 199.90, '/img/placeholder.svg', 4, TRUE, '2026-08-12');

INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (1, '39', 10);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (1, '40', 8);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (1, '41', 5);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (2, '40', 6);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (2, '42', 4);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (3, '38', 7);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (3, '40', 9);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (4, '37', 12);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (4, '39', 12);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (5, '42', 3);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (5, '43', 3);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (6, '40', 15);
INSERT INTO zapatilla_talla (id_zapatilla, talla, stock) VALUES (6, '41', 15);

-- Oferta de ejemplo: 20% en toda la categoría Urbanas
INSERT INTO oferta (nombre, tipo_descuento, valor, fecha_inicio, fecha_fin, activo)
VALUES ('Semana Urbana', 'PORCENTAJE', 20.00, '2026-10-01', '2026-12-31', TRUE);
INSERT INTO oferta_categoria (id_oferta, id_categoria) VALUES (1, 2);
